import React from "react";

function Detail() {
  return <p className="info">{props.detailInfo}</p>;
}

export default Detail;
